#!/usr/bin/env python3
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import Char
from geometry_msgs.msg import Twist

class Nodesuscriptor(Node):
    def __init__(self, name):
        super().__init__(name)


        self.declare_parameter('turtle_speed', 1.0)
        self.declare_parameter('log_level', 'INFO')

        log_level = self.get_parameter('log_level').get_parameter_value().string_value
        if log_level.upper() == 'INFO':
            self.get_logger().set_level(rclpy.logging.LoggingSeverity.INFO)
        elif log_level.upper() == 'WARN':
            self.get_logger().set_level(rclpy.logging.LoggingSeverity.WARN)
        elif log_level.upper() == 'ERROR':
            self.get_logger().set_level(rclpy.logging.LoggingSeverity.ERROR)
        else:
            self.get_logger().warn("Invalid log level, defaulting to INFO")
            self.get_logger().set_level(rclpy.logging.LoggingSeverity.INFO)


        self.suscriber = self.create_subscription(
            Char, "/charstream", self.callback, 10)
        self.publisher_ = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)

    def callback(self, msg):
        turtle_speed = self.get_parameter('turtle_speed').get_parameter_value().double_value

        vector = Twist()
        if msg.data == ord('w'):
            vector.linear.y = turtle_speed
        elif msg.data == ord('a'):
            vector.linear.x = -turtle_speed
        elif msg.data == ord('s'):
            vector.linear.y = -turtle_speed
        elif msg.data == ord('d'):
            vector.linear.x = turtle_speed

        self.publisher_.publish(vector)
        self.get_logger().info(f'Moving turtle with speed: {turtle_speed}')

def main(args=None):
    try:
        print("Application started")
        rclpy.init(args=args)
        nodeSuscriptor = Nodesuscriptor('suscriptor')
        rclpy.spin(nodeSuscriptor)
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()

