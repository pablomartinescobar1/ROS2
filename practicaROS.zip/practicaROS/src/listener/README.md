# listener

To use this package:
1. Build the package (*colcon build*).
2. Run all nodes node with *ros2 launch launch/listener.launch.py*.

