# ros2-keyboard-driver
A simple keyboard driver for ROS 2. 

To use this package:
1. Clone the repo into your ROS 2 workspace.
2. Build the package (*colcon build*).
3. Run the node with *ros2 run keyboard-driver driver*.

Code was adapted from https://answers.ros.org/question/63491/keyboard-key-pressed/. 
